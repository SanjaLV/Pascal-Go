Rails.application.routes.draw do
  devise_for :users
  root 'welcome#index'

  get 'welcome/index'
  post 'change_language', to: 'welcome#change_language', as: :change_language
  post 'welcome/collect_stats'

  resources :posts, only: [:index, :show, :new, :create, :edit, :update, :destroy] do
    resources :comments, only: [:create, :destroy]
    get :search, on: :collection
    resources :votes, only: [:create, :destroy]
  end

  resource :profiles, only: [:edit, :update]
  get 'profiles/:login', to: 'profiles#show', as: :user_profile,
    constraints: { id: /\w+/ }
  get 'profile', to: 'profiles#edit', as: :edit_profile
  patch 'profile', to: 'profiles#update', as: :update_profile
end
