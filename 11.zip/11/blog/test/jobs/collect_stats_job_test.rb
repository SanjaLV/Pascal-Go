require 'test_helper'

class CollectStatsJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
