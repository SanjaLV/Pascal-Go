class Censorship
  ValidationError = Class.new(StandardError)
  BadDetectedError = Class.new(ValidationError)
  AdvertismentDetectedError = Class.new(ValidationError)

  def initialize(text)
    @text = text
    @downcased_text = @text.downcase
  end

  def validate!
    check_bad_words!
    check_advertisement!
  end

  private

  # Samples of bad content
  BADS = ['kill him', 'i hate ruby']
  ADS = ['buy new sock', 'go to my site']

  def check_bad_words!
    has = BADS.detect{|w| @downcased_text.include?(w)}
    raise BadDetectedError, "Found bad #{has}" if has
  end

  def check_advertisement!
    has = ADS.detect{|w| @downcased_text.include?(w)}
    raise AdvertismentDetectedError, "Found advertisment #{has}" if has
  end
end
