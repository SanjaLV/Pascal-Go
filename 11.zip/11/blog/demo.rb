#!/usr/bin/env ruby

def something_bad
  raise 'Black hole'
end

def something_good
  "ruby can do exponontions, 10^10 = #{10**10}"
end

def test_ensure1
  begin
    something_bad
    puts 'Never'
  ensure
    puts 'Forever'
  end
end

def test_ensure1
  puts something_good
ensure
  puts 'Forever'
end

$some_global = 'globals are bad'
def change_global
  $some_global = 'globald are good'
end

def call_with_ensure
  old_value = $some_global
  change_global
  puts $some_global
ensure
  $some_global = old_value
end

def test_ensure_backup
  puts $some_global
  call_with_ensure
  puts $some_global
end


def doing(x)
  raise 'Timeout' if x < 5 # Mimic attemps. for example this is 5 HTTP timeouts
  puts 'ok'
end

def test_retry
  x = 0
  begin
    x += 1
    puts "doing #{x}"
    doing x
  rescue RuntimeError
    puts 'Got error, will try again'
    retry
  end
end


def test_operators
  puts "power 2^10 = #{2**10}"
  puts "2 <=> 3 = #{2 <=> 3}" # -1
  puts "3 <=> 2 = #{3 <=> 2}" # 1
  puts "2 <=> 2 = #{2 <=> 2}" # 0

  puts "(1..10) === 5 is #{(1..10) === 5}"
  x = 5
  case x
  when 1
    puts 'x==1'
  when 0..9
    puts 'x is digit'
  else
    puts 'something else'
  end
  a = case x
  when 1
    123
  else
    321
  end
  puts "a is #{a}"

  a, b, c = 10, 20, 30
  puts "#{a} #{b} #{c}"
  a, b = b, a
  puts "#{a} #{b} #{c}"

  # binary
  puts "#{1 & 2}"
  puts "#{1 & 3}"
  # logically
  puts "#{1 && 2 && 3}"
  puts "#{1 || 2 || 3}"

  # range
  puts "#{(1..10).include?(10)}"
  puts "#{(1...10).include?(10)}"

  # defined or not
  puts "x #{defined?(x)}"
  puts "y #{defined?(y)}"
  y = 1
  puts "y #{defined?(y) && y}"
  puts "test_operators #{defined?(test_operators)}"

  # regex
  puts /oo/ =~ 'foo'
  puts /\d+/ =~ 'foo123bar'
  puts /[A-Z]+/ =~ 'foo123bar'
end

class Num
  def initialize(v)
    @v = v
  end

  def +(value)
    @v += value.is_a?(String) ? value.to_i : value
    self
  end

  def v=(value)
    @v = value
  end

  def v
    @v
  end
end

def test_define_operators
  x = 123
  (x += "1") rescue (puts 'Cannot do it')
  x = Num.new(123)
  x += "1"
  puts "x is #{x.v}"
end

test_ensure1 rescue ''
test_ensure2 rescue ''
test_ensure_backup rescue ''
test_retry

test_operators
test_define_operators
