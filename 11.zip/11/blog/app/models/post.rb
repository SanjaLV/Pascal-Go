class Post < ApplicationRecord
  belongs_to :user
  has_many :comments, dependent: :destroy
  has_many :votes, dependent: :destroy

  validates :title, presence: true
  validates :text, presence: true

  def avg_rating
    return 0 if votes.size.zero?
    total = votes.sum(&:grade)
    (total.to_f / votes.count).round(2)
  end
end
