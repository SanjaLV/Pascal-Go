class Vote < ApplicationRecord
  belongs_to :post

  validates :grade, presence: true
end
