class ProfilesController < ApplicationController
  before_action :authenticate_user!, except: :show

  # Demo filters
  around_action :measure_time
  before_action :ban_vlad2
  after_action :log_current_user

  def show
    @user = User.find_by_login!(params[:login])
  end

  def edit
  end

  def update
    if current_user.update(user_params)
      flash[:notice] = 'Your profile has been changed'
      redirect_to edit_profile_path
    else
      render :edit
    end
  end

  private

  def user_params
    params.require(:user).permit(:login, :email, :full_name)
  end

  def ban_vlad2
    # can also use:
    # raise 'Get out'
    # redirect_to you_are_banned_path
    render plain: 'Get out' if current_user && current_user.login == 'vlad2'
  end

  def measure_time
    started_at = Time.now
    yield
    ended_at = Time.now
    logger.debug "Time taken: #{(ended_at.to_f - started_at.to_f) * 1000} ms"
  end

  def log_current_user
    return unless current_user
    logger.info "#{current_user.email} is whatching profiles from #{request.remote_ip}"
  end

end
