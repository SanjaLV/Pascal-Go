class WelcomeController < ApplicationController
  VALID_LOCALES = [:en, :ru]
  def index
    @users = User.all
  end

  def change_language
    locale = params[:locale] && params[:locale].to_sym
    cookies[:locale] = locale if VALID_LOCALES.include?(locale)
    redirect_back fallback_location: root_path
  end

  def collect_stats
    emails = params[:emails].split(',')
    CollectStatsJob.perform_later(emails)
    redirect_to root_path, notice: "Statistics will be sent to #{emails.inspect}"
  end
end
