class VotesController < ApplicationController
  def create
    @post = Post.find(params[:post_id])
    @vote = @post.votes.create(vote_params)
    redirect_to post_path(@post)
  end

  def destroy
    @post = Post.find(params[:post_id])
    @vote = @post.votes.find(params[:id])
    @vote.destroy
    redirect_to post_path(@post)
  end

  private
    def vote_params
      params.require(:vote).permit(:name, :grade)
    end
end
