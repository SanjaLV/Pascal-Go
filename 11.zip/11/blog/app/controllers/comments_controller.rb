class CommentsController < ApplicationController
  def create
    @post = Post.find(params[:post_id])
    Censorship.new(comment_params[:text]).validate!
    @comment = @post.comments.create(comment_params)
    UserMailer.notify_comment(@post.user, @comment).deliver_later
    redirect_to post_path(@post)
  rescue Censorship::ValidationError => ex
    Rails.logger.debug "Comment rejected, reason #{ex.message}"
    redirect_to post_path(@post), alert: t('your_comment_is_bad')
  end

  def destroy
    @post = Post.find(params[:post_id])
    @comment = @post.comments.find(params[:id])
    @comment.destroy
    flash[:notice] = t 'comment_was_deleted'
    redirect_to post_path(@post)
  end

  private
    def comment_params
      params.require(:comment).permit(:name, :text)
    end
end
