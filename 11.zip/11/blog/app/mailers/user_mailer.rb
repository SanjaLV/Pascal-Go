class UserMailer < ApplicationMailer

  def notify_comment(user, comment)
    @user = user
    @comment = comment
    mail(to: @user.email, subject: t('user_commented_your_post', user_name: @comment.name))
  end

  def notify_text(email, subject, text)
    mail(to: email, subject: subject) do |format|
      format.text { render text: text }
    end
  end
end
