class ApplicationMailer < ActionMailer::Base
  default from: 'no-reply@superblog.com'
  layout 'mailer'
end
