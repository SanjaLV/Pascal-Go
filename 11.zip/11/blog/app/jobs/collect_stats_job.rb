class CollectStatsJob < ApplicationJob
  queue_as :default

  rescue_from(Exception) do |exception|
    Rails.logger.error "Got #{exception.class} #{exception.message}"
    Rails.logger.error "#{exception.backtrace * "\n"}"
  end

  # demo hooks
  before_enqueue do |job|
    Rails.logger.debug "Scheduled job at #{Time.now.utc}. #{job.inspect}"
  end

  around_perform do |job, block|
    Rails.logger.debug "Running job at #{Time.now.utc}. #{job.inspect}"
    block.call
  end

  def perform(emails)
    started_at = Time.now.utc
    lines = []
    lines << "Users: #{User.count}"
    lines << "Posts: #{Post.count}"
    lines << "Comments: #{Comment.count}"
    lines << "Votes: #{Vote.count}"
    lines << "Most active users:"
    # SELECT  COUNT(*) AS count_all, "posts"."user_id" AS posts_user_id FROM "posts" GROUP BY "posts"."user_id" ORDER BY count_all DESC LIMIT ?
    top = Post.group(:user_id).order("count_all DESC").limit(10).count
    top.each do |user_id, count|
      lines << "  #{User.find(user_id).login} - #{count}"
    end

    lines << "Most commented posts:"
    top = Comment.group(:post_id).order("count_all DESC").limit(10).count
    top.each do |post_id, count|
      lines << "  #{Post.find(post_id).text} - #{count}"
    end

    lines << "Time taken #{Time.now.utc - started_at} seconds"

    body = lines.join("\n")
    emails.each{|e| send_mail(body, e)}
  end

  private

  def send_mail(body, recipient)
    UserMailer.notify_text(recipient, "Statistics", body).deliver
  end
end
