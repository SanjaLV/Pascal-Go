# rails g model Vote name:string grade:integer post:references
class CreateVotes < ActiveRecord::Migration[5.0]
  def change
    create_table :votes do |t|
      t.string :name
      t.integer :grade
      t.references :post, foreign_key: true

      t.timestamps
    end
  end
end
